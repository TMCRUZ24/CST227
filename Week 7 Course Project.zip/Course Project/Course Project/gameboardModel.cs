﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Project
{
    abstract class gameboardModel{

        public bool PlayerLost { set; get; }
        public int NumOfColumns { set; get; }
        public int NumOfRows { set; get; }
        public clickableCell[,] Gameboard { set; get; }
        public int SafeTiles { set; get; }
        public int numOfLiveCells { set; get; }
        public bool GameOver { set; get; }

        public gameboardModel()
        {
            this.NumOfRows = 10;
            this.NumOfColumns = 10;
            this.SafeTiles = NumOfColumns * NumOfRows;
            this.Gameboard = new clickableCell[10, 10];
        }

        public void setGameBoard(){
            //initialize gameboard without live cells
            for (int row = 0; row < NumOfRows; row++)
            {
                for (int column = 0; column < NumOfColumns; column++)
                {
                    Gameboard[row, column] = new clickableCell(row, column);
                }
            }

            //Gameboard will contain roughly 20% "live" cells
            numOfLiveCells = (NumOfColumns * NumOfRows) / 5;
            int counter = 0;
            Random rand = new Random();

            //set gameboard with "live" cells
            do{
                int rowRand = rand.Next(NumOfRows);
                int columnRand = rand.Next(NumOfColumns);

                //Random live cell placement on the gameboard
                if (Gameboard[rowRand, columnRand].IsLive == false){
                    Gameboard[rowRand, columnRand].IsLive = true;
                    counter++;
             

                    //Increment "Number of Live Neighbors" value for row above live cell
                    if (rowRand > 0)
                    {
                        if (columnRand > 0)
                        {
                            Gameboard[rowRand - 1, columnRand - 1].NumberOfLiveNeighbors++;
                        }

                        Gameboard[rowRand - 1, columnRand].NumberOfLiveNeighbors++;

                        if (NumOfColumns - 1 > columnRand)
                        {
                            Gameboard[rowRand - 1, columnRand + 1].NumberOfLiveNeighbors++;
                        }
                    }

                    //Increment "Number of Live Neighbors" value for same row as live cell
                    if (columnRand > 0)
                    {
                        Gameboard[rowRand, columnRand - 1].NumberOfLiveNeighbors++;
                    }

                    if (columnRand < NumOfColumns - 1)
                    {
                        Gameboard[rowRand, columnRand + 1].NumberOfLiveNeighbors++;
                    }

                    //Increment "Number of Live Neighbors" value for row below live cell
                    if (rowRand < NumOfRows - 1)
                    {
                        if (columnRand > 0)
                        {
                            Gameboard[rowRand + 1, columnRand - 1].NumberOfLiveNeighbors++;
                        }

                        Gameboard[rowRand + 1, columnRand].NumberOfLiveNeighbors++;

                        if (columnRand < NumOfColumns - 1)
                        {
                            Gameboard[rowRand + 1, columnRand + 1].NumberOfLiveNeighbors++;
                        }
                    }
                }

            } while (counter < numOfLiveCells);

            this.SafeTiles = (NumOfColumns * NumOfRows) - counter;
        }

        public void displayEntireBoard(bool playerLost)
        {
            Console.Write("  ");
            for (int column = 0; column < NumOfColumns; column++)
            {
                Console.Write(column);
            }
            Console.WriteLine("");
            
            for (int row = 0; row < NumOfRows; row++)
            {
                Console.Write(row);
                Console.Write("|");
                for (int column = 0; column <NumOfColumns; column++)
                {
                    if (Gameboard[row, column].IsLive == true)
                    {
                        Console.Write("*");
                    }
                    else if (Gameboard[row, column].NumberOfLiveNeighbors > 0)
                    {
                        Console.Write(Gameboard[row, column].NumberOfLiveNeighbors);
                    }
                    else
                    {
                        Gameboard[row, column].DisplayTile = "~";
                        Console.Write(Gameboard[row,column].DisplayTile);
                    }
                }
                Console.WriteLine("");
            }
            if (playerLost)
            {
                Console.WriteLine("You hit a mine! You Lose!!");
            }
            else
            {
                Console.WriteLine("Congratulations! You win!!");
            }
        }

        public abstract void playConsoleGame();

        public abstract void displayGameboard();

        public abstract bool checkIsLive(int x, int y);

        public abstract void revealTile(int x, int y);

    }
}