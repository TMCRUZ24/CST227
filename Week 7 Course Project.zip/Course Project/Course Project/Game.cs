﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Course_Project
{
    public partial class GameWindow : Form
    {
        //Gameboard Data
        clickableCell[,] cellArray;
        gameboardModel GameModel;

        //Gamebaord dimensions determined by difficulty
        private int numOfColumns, numOfRows;
        const int EASY = 10;
        const int INTERMEDIATE = 15;
        const int DIFFICULT = 20;

        //Grid Location Data
        const int START_X = 20;
        const int START_Y = 75;
        const int CELL_SIZE = 25;

        //Timer data
        const int EASY_TIMER = 100;
        const int INTERMEDIATE_TIMER = 250;
        const int DIFFICULT_TIMER = 500;
        private Timer timer;
        private int counter;
        private Label lbl_countdown = new Label();

        //Leaderboard Data
        private Label Lbl_Inits = new Label();
        private TextBox TB_Inits = new System.Windows.Forms.TextBox();
        private Button Btn_Go = new Button();
        private List<string> recordFileIn = new List<string>();
        private List<PlayerStats> AllPlayers = new List<PlayerStats>();
        private List<PlayerStats> EasyPlayers = new List<PlayerStats>();
        private List<PlayerStats> IntermediatePlayers = new List<PlayerStats>();
        private List<PlayerStats> DifficultPlayers = new List<PlayerStats>();
        private IEnumerable<PlayerStats> SortedLeaders = new List<PlayerStats>();
        private string difficulty;
        private string initials;
        private int score;
        private const string FILEPATH = "scores.txt";

        //Initialize Form (Game)
        public GameWindow()
        {
            InitializeComponent();
        }
                   
        //Sets Game Data and Window Size for "EASY" Game
        private void MenuStrip_Easy_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[EASY, EASY];
            GameModel = new Minesweeper(EASY, EASY);
            numOfColumns = numOfRows = EASY;
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game DIFFICULT
            this.Width = EASY * CELL_SIZE + (3 * START_X);
            this.Height = EASY * CELL_SIZE + (2 * START_Y);

            //Initialize Button Grid
            for (int row = 0; row < EASY; row++)
            {
                for(int col = 0; col < EASY; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * CELL_SIZE + START_X, col * CELL_SIZE + START_Y);
                    cellArray[row, col].MouseDown += new MouseEventHandler(btn_Click);
                    this.Controls.Add(cellArray[row, col]);
                }
            }

            //Initialize Timer
            counter = EASY_TIMER;
            timer = new Timer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = 1000;
            lbl_countdown.Size = new System.Drawing.Size(70, 35);
            lbl_countdown.Name = "lbl_timer";
            lbl_countdown.Location = new System.Drawing.Point(this.Width - 110, 25);
            lbl_countdown.Text = counter.ToString();
            lbl_countdown.BackColor = Color.Black;
            lbl_countdown.ForeColor = Color.Red;
            lbl_countdown.Font = new Font("Gil Ultra Sans", 24, FontStyle.Regular);
            this.Controls.Add(lbl_countdown);
            timer.Start();
        }

        //Sets Game Data and Window Size for "Intermediate" Game
        private void MenuStrip_Intermediate_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[INTERMEDIATE, INTERMEDIATE];
            GameModel = new Minesweeper(INTERMEDIATE, INTERMEDIATE);
            numOfRows = numOfColumns = INTERMEDIATE;
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game DIFFICULT
            this.Width = INTERMEDIATE * CELL_SIZE + (3 * START_X);
            this.Height = INTERMEDIATE * CELL_SIZE + (2 * START_Y);

            //Initialize Button Grid
            for (int row = 0; row < INTERMEDIATE; row++)
            {
                for (int col = 0; col < INTERMEDIATE; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * CELL_SIZE + START_X, col * CELL_SIZE + START_Y);
                    cellArray[row, col].MouseDown += new MouseEventHandler(btn_Click);
                    this.Controls.Add(cellArray[row, col]);
                }
            }

            //Initialize Timer
            counter = INTERMEDIATE_TIMER;
            timer = new Timer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = 1000;
            lbl_countdown.Size = new System.Drawing.Size(75, 35);
            lbl_countdown.Name = "lbl_timer";
            lbl_countdown.Location = new System.Drawing.Point(this.Width - 115, 25);
            lbl_countdown.Text = counter.ToString();
            lbl_countdown.BackColor = Color.Black;
            lbl_countdown.ForeColor = Color.Red;
            lbl_countdown.Font = new Font("Gil Ultra Sans", 24, FontStyle.Regular);
            this.Controls.Add(lbl_countdown);
            timer.Start();
        }

        //Sets Game Data and Window Size for "Difficult" Game
        private void MenuStrip_Difficult_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[DIFFICULT, DIFFICULT];
            GameModel = new Minesweeper(DIFFICULT, DIFFICULT);
            numOfColumns = numOfRows = DIFFICULT;
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game DIFFICULT
            this.Width = DIFFICULT * CELL_SIZE + (3 * START_X);
            this.Height = DIFFICULT * CELL_SIZE + (2 * START_Y);

            //Initialize Button Grid
            for (int row = 0; row < DIFFICULT; row++)
            {
                for (int col = 0; col < DIFFICULT; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * CELL_SIZE + START_X, col * CELL_SIZE + START_Y);
                    cellArray[row, col].MouseDown += new MouseEventHandler(btn_Click);
                    this.Controls.Add(cellArray[row, col]);
                }
            }

            //Initialize Timer                                         
            counter = DIFFICULT_TIMER;
            timer = new Timer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = 1000;
            lbl_countdown.Size = new System.Drawing.Size(75, 35);
            lbl_countdown.Name = "lbl_timer";
            lbl_countdown.Location = new System.Drawing.Point(this.Width - 115, 25);
            lbl_countdown.Text = counter.ToString();
            lbl_countdown.BackColor = Color.Black;
            lbl_countdown.ForeColor = Color.Red;
            lbl_countdown.Font = new Font("Gil Ultra Sans", 24, FontStyle.Regular);
            this.Controls.Add(lbl_countdown);
            timer.Start();
        }

        //Timer event method
        private void timer_Tick(object sender, EventArgs e)
        {
            //Timer logic, counts down from starting point.
            counter--;
            if (counter == 0)
            {
                timer.Stop();  
            }
            lbl_countdown.Text = counter.ToString();
        }

        //Event Handler for button click (Cell Selection)
        private void btn_Click(object sender, MouseEventArgs e)
        {
            clickableCell xyButton = sender as clickableCell;

            switch (e.Button)
            {
                case MouseButtons.Right:
                    //Add flag to button to mark it as a mine
                    if(cellArray[xyButton.ColumnLoc, xyButton.RowLoc].Image != null)
                    {
                        cellArray[xyButton.ColumnLoc, xyButton.RowLoc].Image = null;
                    }
                    else
                    {
                        cellArray[xyButton.ColumnLoc, xyButton.RowLoc].Image = global::Course_Project.Properties.Resources.FlagMarker;
                    }
                    break;
                case MouseButtons.Left:
                    //Passes cell location to function to reveal selection
                    revealTiles(xyButton.ColumnLoc, xyButton.RowLoc);

                    //If no safe tiles exist, trigger a win. Otherwise, continue game with newly revealed tile
                    if (GameModel.SafeTiles == 0)
                    {
                        timer.Stop();
                        if (GameModel.GameOver == false)
                        {
                            GameModel.GameOver = true;
                            openGameBoard(false, GameModel.Gameboard.Length);
                        }
                    }
                    break;
            }
        }

        //Recursive function used to reveal selection. Recursive if user selects empty cell that's not live and has no live neighbors
        private void revealTiles(int col, int row)
        {
            //Removes the button
            this.Controls.Remove(cellArray[col, row]);

            //Creates Label that will be used to replace the button after click
            Label lbl = new Label();
            lbl.Size = new System.Drawing.Size(25, 25);
            lbl.Name = row + "" + col;
            lbl.Location = new System.Drawing.Point(col * CELL_SIZE + START_X, row * CELL_SIZE + START_Y);

            //Logic used to determine action based on what the cell contains that's selected by the user
            if (GameModel.Gameboard[row, col].IsLive)
            {
                timer.Stop();
                lbl.Image = global::Course_Project.Properties.Resources.MineMarker;
                this.Controls.Add(lbl);

                if (GameModel.GameOver == false)
                {
                    GameModel.GameOver = true;
                    openGameBoard(true, 0);
                }
            }
            else if (GameModel.Gameboard[row, col].NumberOfLiveNeighbors > 0)
            {
                GameModel.SafeTiles--;
                lbl.Text = GameModel.Gameboard[row, col].NumberOfLiveNeighbors.ToString();
                this.Controls.Add(lbl);
            }
            //If user selects empty tile that has no mine and no numeric indicator. This is where recursion takes place
            else
            {
                GameModel.SafeTiles--;
                lbl.Text = "";
                this.Controls.Add(lbl);

                //Display tiles in the row above user-selected empty tile
                if (row > 0)
                {
                    if (col > 0)
                    {
                        if (GameModel.Gameboard[row - 1, col - 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row - 1, col - 1].WasVisited = true;
                            revealTiles(col - 1, row - 1);
                        }
                    }

                    if (GameModel.Gameboard[row - 1, col].WasVisited == false)
                    {
                        GameModel.Gameboard[row - 1, col].WasVisited = true;
                        revealTiles(col, row - 1);
                    }

                    if (GameModel.NumOfColumns - 1 > col)
                    {
                        if (GameModel.Gameboard[row - 1, col + 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row - 1, col + 1].WasVisited = true;
                            revealTiles(col + 1, row - 1);
                        }
                    }
                }

                //Display tiles in the same row as user-selected empty tile
                if (col > 0)
                {
                    if (GameModel.Gameboard[row, col - 1].WasVisited == false)
                    {
                        GameModel.Gameboard[row, col - 1].WasVisited = true;
                        revealTiles(col - 1, row);
                    }
                }

                if (col < GameModel.NumOfColumns - 1)
                {
                    if (GameModel.Gameboard[row, col + 1].WasVisited == false)
                    {
                        GameModel.Gameboard[row, col + 1].WasVisited = true;
                        revealTiles(col + 1, row);
                    }
                }

                //Display tiles in the row below user-selected empty tile
                if (row < GameModel.NumOfRows - 1)
                {
                    if (col > 0)
                    {
                        if (GameModel.Gameboard[row + 1, col - 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row + 1, col - 1].WasVisited = true;
                            revealTiles(col - 1, row + 1);
                        }
                    }

                    if (GameModel.Gameboard[row + 1, col].WasVisited == false)
                    {
                        GameModel.Gameboard[row + 1, col].WasVisited = true;
                        revealTiles(col, row + 1);
                    }

                    if (GameModel.NumOfColumns - 1 > col)
                    {
                        if (GameModel.Gameboard[row + 1, col + 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row + 1, col + 1].WasVisited = true;
                            revealTiles(col + 1, row + 1);
                        }
                    }
                }
            }
        }

        //function used to display entire game board after win/loss
        private void openGameBoard(bool playerLost, int key)
        {
            GameModel.PlayerLost = playerLost;

            if (playerLost)
            {
                for (int i = 0; i < numOfColumns; i++)
                {
                    for (int j = 0; j < numOfRows; j++)
                    {
                        revealTiles(i, j);
                    }
                }
                DialogResult result = MessageBox.Show("You hit a mine! You Lose!");
            }
            else
            {

                for (int i = 0; i < numOfColumns; i++)
                {
                    for (int j = 0; j < numOfRows; j++)
                    {
                        this.Controls.Remove(cellArray[i,j]);
                    }
                }

                Lbl_Inits.AutoSize = true;
                Lbl_Inits.Font = new System.Drawing.Font("Gill Sans MT", 8, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                Lbl_Inits.ForeColor = System.Drawing.Color.Green;
                Lbl_Inits.Location = new System.Drawing.Point(0, 25);
                Lbl_Inits.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
                Lbl_Inits.Name = "Lbl_Initials";
                Lbl_Inits.Size = new System.Drawing.Size(326, 26);
                Lbl_Inits.TabIndex = 0;
                Lbl_Inits.Text = "Congratulations! Please Enter Your Initials: ";
                this.Controls.Add(Lbl_Inits);

                TB_Inits.Location = new System.Drawing.Point(70, 45);
                TB_Inits.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
                TB_Inits.Multiline = true;
                TB_Inits.Name = "TB_Initials";
                TB_Inits.Size = new System.Drawing.Size(61, 26);
                TB_Inits.TabIndex = 2;
                this.Controls.Add(TB_Inits);

                Btn_Go.Font = new System.Drawing.Font("Gill Sans MT", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                Btn_Go.Location = new System.Drawing.Point(140, 45);
                Btn_Go.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
                Btn_Go.Name = "";
                Btn_Go.Size = new System.Drawing.Size(51, 24);
                Btn_Go.TabIndex = 3;
                Btn_Go.Text = "Go!";
                Btn_Go.UseVisualStyleBackColor = true;
                Btn_Go.Click += new System.EventHandler(this.Btn_CreateLeader_Click);
                this.Controls.Add(Btn_Go);

                DialogResult result = MessageBox.Show("You Win! Please Enter Your Initials!");
            }
        }
        
        //Creates a new PlayerStats object to add to leaderboard
        private void Btn_CreateLeader_Click(object sender, EventArgs e)
        {
            Button createPlayer = sender as Button;

            //Assign a value to "Score"
            score = counter;

            //Assign a value to "Initials
            try
            {
                initials = TB_Inits.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Assign a value to "DIFFICULT" and create new player record in "Scores" file
            if (numOfColumns == EASY)
            {
                difficulty = "Easy";
                PlayerStats newPlayer = new PlayerStats(difficulty, initials, score);
                recordFileIn.Add(newPlayer.ToString());
                File.AppendAllLines(FILEPATH, recordFileIn);
                retrieveLeaders(difficulty);
            }
            else if(numOfColumns == INTERMEDIATE)
            {
                difficulty = "Intermediate";
                PlayerStats newPlayer = new PlayerStats(difficulty, initials, score);
                recordFileIn.Add(newPlayer.ToString());
                File.AppendAllLines(FILEPATH, recordFileIn);
                retrieveLeaders(difficulty);
            }
            else if(numOfColumns == DIFFICULT)
            {
                difficulty = "Difficult";
                PlayerStats newPlayer = new PlayerStats(difficulty, initials, score);
                recordFileIn.Add(newPlayer.ToString());
                File.AppendAllLines(FILEPATH, recordFileIn);
                retrieveLeaders(difficulty);
            }
            else
            {
                MessageBox.Show("could not initialize player data");
            }            
        }

        //Reads data from text file to populate leaders in each difficulty
        private void retrieveLeaders(String difficulty)
        {
            int Lbl_LocY = 35;
            int Lbl_LocX = 75;

            this.Controls.Clear();

            Label Lbl_LeaderTitle = new Label();
            Lbl_LeaderTitle.AutoSize = true;
            Lbl_LeaderTitle.Font = new System.Drawing.Font("Gill Sans Ultra", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Lbl_LeaderTitle.Location = new System.Drawing.Point(Lbl_LocX, Lbl_LocY);
            Lbl_LeaderTitle.Name = "Lbl_Leaders";
            Lbl_LeaderTitle.Size = new System.Drawing.Size(178, 21);
            Lbl_LeaderTitle.TabIndex = 4;
            Lbl_LeaderTitle.Text = difficulty + " Leaderboard:";
            this.Controls.Add(Lbl_LeaderTitle);
            Lbl_LocY += 60;

            //read file data and store in List
            File.ReadAllLines(FILEPATH);
            recordFileIn = File.ReadAllLines(FILEPATH).ToList();
            foreach (string line in recordFileIn)
            {
                string[] entries = line.Split(' ');
                PlayerStats newPlayer = new PlayerStats(entries[0], entries[1], Convert.ToInt32(entries[2]));
                AllPlayers.Add(newPlayer);
            }

            //List of 5 Players (Leaders) based on difficulty
            switch (difficulty)
            {
                case "Easy":

                    SortedLeaders = (from Player in AllPlayers
                                     where Player.difficulty == "Easy"
                                     select Player).OrderByDescending(newPlayer => newPlayer.score).Take(5).ToList(); 
                    break;
                case "Intermediate":
                    SortedLeaders = (from Player in AllPlayers
                                     where Player.difficulty == "Intermediate"
                                     select Player).OrderByDescending(newPlayer => newPlayer.score).Take(5).ToList();
                    break;
                case "Difficult":
                    SortedLeaders = (from Player in AllPlayers
                                     where Player.difficulty == "Difficult"
                                     select Player).OrderByDescending(newPlayer => newPlayer.score).Take(5).ToList();
                    break;
                default:
                    MessageBox.Show("Could not find difficulty level");
                    break;
            }

            //Displays Top 5 Leaders
            foreach (var leader in SortedLeaders)
            {
                Label Lbl_Leaders = new Label();
                Lbl_Leaders.AutoSize = true;
                Lbl_Leaders.Font = new System.Drawing.Font("Gill Sans Ultra", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                Lbl_Leaders.ForeColor = System.Drawing.Color.Red;
                Lbl_Leaders.Location = new System.Drawing.Point(Lbl_LocX, Lbl_LocY);
                Lbl_Leaders.Name = "Lbl_Leaders";
                Lbl_Leaders.Size = new System.Drawing.Size(178, 21);
                Lbl_Leaders.TabIndex = 4;
                Lbl_Leaders.Text = leader.ToString();
                this.Controls.Add(Lbl_Leaders);
                Lbl_LocY += 35;
            }
        }

        private void MenuStrip_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}