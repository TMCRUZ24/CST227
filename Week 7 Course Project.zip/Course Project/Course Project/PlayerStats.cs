﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Project
{
    class PlayerStats : IComparable
    {
        public string difficulty { set; get; }
        public int score { set; get; }
        private string inits;
        public string initials
        {
            get { return inits; }
            set
            {
                if(value.Length <= 3 && value.Length > 0)
                {
                    inits = value;
                }
                else
                {
                    Console.WriteLine(value.Length);
                    throw new Exception("Initials must be entered and can only contain 3 characters!");
                }
            }
        }

        public PlayerStats(string difficulty, string initials, int score)
        {
            this.difficulty = difficulty;
            this.initials = initials;
            this.score = score;
        }

        public int CompareTo(object obj)
        {
            return this.score.CompareTo(obj);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(this.difficulty);
            sb.Append(" ");
            sb.Append(this.initials);
            sb.Append(" ");
            sb.Append(this.score);
            return sb.ToString();
        }
    }
}
