﻿namespace Course_Project
{
    partial class GameWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameWindow));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuStrip_SelectGame = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_NewGame = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_Easy = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_Intermediate = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_Difficult = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.Lbl_Welcome = new System.Windows.Forms.Label();
            this.PB_Mine = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Mine)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuStrip_SelectGame});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(365, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuStrip_SelectGame
            // 
            this.MenuStrip_SelectGame.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuStrip_NewGame,
            this.MenuStrip_Exit});
            this.MenuStrip_SelectGame.Name = "MenuStrip_SelectGame";
            this.MenuStrip_SelectGame.Size = new System.Drawing.Size(84, 20);
            this.MenuStrip_SelectGame.Text = "Select Game";
            // 
            // MenuStrip_NewGame
            // 
            this.MenuStrip_NewGame.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuStrip_Easy,
            this.MenuStrip_Intermediate,
            this.MenuStrip_Difficult});
            this.MenuStrip_NewGame.Name = "MenuStrip_NewGame";
            this.MenuStrip_NewGame.Size = new System.Drawing.Size(180, 22);
            this.MenuStrip_NewGame.Text = "New Game";
            // 
            // MenuStrip_Easy
            // 
            this.MenuStrip_Easy.Name = "MenuStrip_Easy";
            this.MenuStrip_Easy.Size = new System.Drawing.Size(141, 22);
            this.MenuStrip_Easy.Text = "Easy";
            this.MenuStrip_Easy.Click += new System.EventHandler(this.MenuStrip_Easy_Click);
            // 
            // MenuStrip_Intermediate
            // 
            this.MenuStrip_Intermediate.Name = "MenuStrip_Intermediate";
            this.MenuStrip_Intermediate.Size = new System.Drawing.Size(141, 22);
            this.MenuStrip_Intermediate.Text = "Intermediate";
            this.MenuStrip_Intermediate.Click += new System.EventHandler(this.MenuStrip_Intermediate_Click);
            // 
            // MenuStrip_Difficult
            // 
            this.MenuStrip_Difficult.Name = "MenuStrip_Difficult";
            this.MenuStrip_Difficult.Size = new System.Drawing.Size(141, 22);
            this.MenuStrip_Difficult.Text = "Difficult";
            this.MenuStrip_Difficult.Click += new System.EventHandler(this.MenuStrip_Difficult_Click);
            // 
            // MenuStrip_Exit
            // 
            this.MenuStrip_Exit.Name = "MenuStrip_Exit";
            this.MenuStrip_Exit.Size = new System.Drawing.Size(180, 22);
            this.MenuStrip_Exit.Text = "Exit";
            this.MenuStrip_Exit.Click += new System.EventHandler(this.MenuStrip_Exit_Click);
            // 
            // Lbl_Welcome
            // 
            this.Lbl_Welcome.AutoSize = true;
            this.Lbl_Welcome.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Welcome.Location = new System.Drawing.Point(75, 210);
            this.Lbl_Welcome.Name = "Lbl_Welcome";
            this.Lbl_Welcome.Size = new System.Drawing.Size(224, 43);
            this.Lbl_Welcome.TabIndex = 1;
            this.Lbl_Welcome.Text = "MINESWEEPER!";
            // 
            // PB_Mine
            // 
            this.PB_Mine.Image = global::Course_Project.Properties.Resources.mine;
            this.PB_Mine.Location = new System.Drawing.Point(119, 60);
            this.PB_Mine.Name = "PB_Mine";
            this.PB_Mine.Size = new System.Drawing.Size(126, 126);
            this.PB_Mine.TabIndex = 2;
            this.PB_Mine.TabStop = false;
            // 
            // GameWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 296);
            this.Controls.Add(this.PB_Mine);
            this.Controls.Add(this.Lbl_Welcome);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GameWindow";
            this.Text = "Game";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Mine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_SelectGame;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_NewGame;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_Easy;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_Intermediate;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_Difficult;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_Exit;
        private System.Windows.Forms.Label Lbl_Welcome;
        private System.Windows.Forms.PictureBox PB_Mine;
    }
}