﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Project
{
    class clickableCell : Button
    {
        public bool WasVisited { get; set; }
        public bool IsLive { get; set; }
        public int NumberOfLiveNeighbors { get; set; }
        public String DisplayTile { get; set; }
        public int RowLoc { get; set; }
        public int ColumnLoc { get; set; }

        public clickableCell(int column, int row)
        {
            this.WasVisited = false;
            this.IsLive = false;
            this.NumberOfLiveNeighbors = 0;
            this.DisplayTile = "?";
            this.RowLoc = row;
            this.ColumnLoc = column;

            this.Text = "";
            this.Size = new System.Drawing.Size(25, 25);
        }
    }
}
