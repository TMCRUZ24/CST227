﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Project
{
    public partial class GameWindow : Form
    {
        //Gameboard Data
        clickableCell[,] cellArray;
        gameboardModel GameModel;

        //Gamebaord dimensions determined by difficulty
        int easy = 10;
        int intermediate = 25;
        int difficultX = 50;
        int difficultY = 25;

        //Grid Location Data
        int startX = 20;
        int startY = 60;
        int cellSize = 25;

        //Initialize Form (Game)
        public GameWindow()
        {
            InitializeComponent();
        }
                   
        //Sets Game Data and Window Size for "Easy" Game
        private void MenuStrip_Easy_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[easy, easy];
            GameModel = new Minesweeper(easy, easy);
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game difficulty
            this.Width = easy * cellSize + (3 * startX);
            this.Height = easy * cellSize + (2 * startY);

            //Initialize Button Grid
            for (int row = 0; row < easy; row++)
            {
                for(int col = 0; col < easy; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * cellSize + startX, col * cellSize + startY);
                    cellArray[row, col].Click += btn_Click;
                    this.Controls.Add(cellArray[row, col]);
                }
            }
        }

        //Sets Game Data and Window Size for "Intermediate" Game
        private void MenuStrip_Intermediate_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[intermediate, intermediate];
            GameModel = new Minesweeper(intermediate, intermediate);
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game difficulty
            this.Width = intermediate * cellSize + (3 * startX);
            this.Height = intermediate * cellSize + (2 * startY);

            //Initialize Button Grid
            for (int row = 0; row < intermediate; row++)
            {
                for (int col = 0; col < intermediate; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * cellSize + startX, col * cellSize + startY);
                    cellArray[row, col].Click += btn_Click;
                    this.Controls.Add(cellArray[row, col]);
                }
            }
        }

        //Sets Game Data and Window Size for "Difficult" Game
        private void MenuStrip_Difficult_Click(object sender, EventArgs e)
        {
            //Remove Image and "Welcome" Label from window
            this.Controls.Remove(PB_Mine);
            this.Controls.Remove(Lbl_Welcome);

            //Declare Button Grid and Set Game Data
            cellArray = new clickableCell[difficultX, difficultY];
            GameModel = new Minesweeper(difficultX, difficultY);
            GameModel.setGameBoard();

            GameModel.displayEntireBoard(true);//<-----------------FOR TESTING

            //Resize window based on game difficulty
            this.Width = difficultX * cellSize + (3 * startX);
            this.Height = difficultY * cellSize + (2 * startY);

            //Initialize Button Grid
            for (int row = 0; row < difficultX; row++)
            {
                for (int col = 0; col < difficultY; col++)
                {
                    cellArray[row, col] = new clickableCell(row, col);
                    cellArray[row, col].Name = row + "" + col;
                    cellArray[row, col].Text = "";
                    cellArray[row, col].Location = new System.Drawing.Point(row * cellSize + startX, col * cellSize + startY);
                    cellArray[row, col].Click += btn_Click;
                    this.Controls.Add(cellArray[row, col]);
                }
            }
        }

        //Event Handler for button click (Cell Selection)
        private void btn_Click(object sender, EventArgs e)
        {
            clickableCell xyButton = sender as clickableCell;
            
           //Passes cell location to function to reveal selection
            revealTiles(xyButton.ColumnLoc, xyButton.RowLoc);

                        
            //If no safe tiles exist, trigger a win. Otherwise, continue game with newly revealed tile
            if (GameModel.SafeTiles == 0)
            {
                DialogResult result = MessageBox.Show("You Win!");
            }

        }

        //Recursive function used to reveal selection. Only recursive if user selects and empty cell that's not live and has no live neighbors
        private void revealTiles(int col, int row)
        {
            //Removes the button
            this.Controls.Remove(cellArray[col, row]);

            //Creates Label that will be used to replace the button after click
            Label lbl = new Label();
            lbl.Size = new System.Drawing.Size(25, 25);
            lbl.Name = row + "" + col;
            lbl.Location = new System.Drawing.Point(col * cellSize + startX, row * cellSize + startY);

            //Logic used to determine action based on what the cell contains that's selected by the user
            if (GameModel.Gameboard[row, col].IsLive)
            {
                //TODO Player Loses
                lbl.Text = "X";
                this.Controls.Add(lbl);
                DialogResult result = MessageBox.Show("You hit a mine! You Lose!");
            }
            else if (GameModel.Gameboard[row, col].NumberOfLiveNeighbors > 0)
            {
                GameModel.SafeTiles--;
                lbl.Text = GameModel.Gameboard[row, col].NumberOfLiveNeighbors.ToString();
                this.Controls.Add(lbl);
            }
            //If user selects empty tile that has no mine and no numeric indicator. This is where recursion takes place
            else
            {
                GameModel.SafeTiles--;
                lbl.Text = "";
                this.Controls.Add(lbl);

                //Display tiles in the row above user-selected empty tile
                if (row > 0)
                {
                    if (col > 0)
                    {
                        if (GameModel.Gameboard[row - 1, col - 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row - 1, col - 1].WasVisited = true;
                            revealTiles(col - 1, row - 1);
                        }
                    }

                    if (GameModel.Gameboard[row - 1, col].WasVisited == false)
                    {
                        GameModel.Gameboard[row - 1, col].WasVisited = true;
                        revealTiles(col, row - 1);
                    }

                    if (GameModel.NumOfColumns - 1 > col)
                    {
                        if (GameModel.Gameboard[row - 1, col + 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row - 1, col + 1].WasVisited = true;
                            revealTiles(col + 1, row - 1);
                        }
                    }
                }

                //Display tiles in the same row as user-selected empty tile
                if (col > 0)
                {
                    if (GameModel.Gameboard[row, col - 1].WasVisited == false)
                    {
                        GameModel.Gameboard[row, col - 1].WasVisited = true;
                        revealTiles(col - 1, row);
                    }
                }

                if (col < GameModel.NumOfColumns - 1)
                {
                    if (GameModel.Gameboard[row, col + 1].WasVisited == false)
                    {
                        GameModel.Gameboard[row, col + 1].WasVisited = true;
                        revealTiles(col + 1, row);
                    }
                }

                //Display tiles in the row below user-selected empty tile
                if (row < GameModel.NumOfRows - 1)
                {
                    if (col > 0)
                    {
                        if (GameModel.Gameboard[row + 1, col - 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row + 1, col - 1].WasVisited = true;
                            revealTiles(col - 1, row + 1);
                        }
                    }

                    if (GameModel.Gameboard[row + 1, col].WasVisited == false)
                    {
                        GameModel.Gameboard[row + 1, col].WasVisited = true;
                        revealTiles(col, row + 1);
                    }

                    if (GameModel.NumOfColumns - 1 > col)
                    {
                        if (GameModel.Gameboard[row + 1, col + 1].WasVisited == false)
                        {
                            GameModel.Gameboard[row + 1, col + 1].WasVisited = true;
                            revealTiles(col + 1, row + 1);
                        }
                    }
                }
            }

        }
    }
}
